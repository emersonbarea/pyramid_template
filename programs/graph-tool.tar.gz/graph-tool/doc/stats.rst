.. automodule:: graph_tool.stats
   :members:
   :undoc-members:
