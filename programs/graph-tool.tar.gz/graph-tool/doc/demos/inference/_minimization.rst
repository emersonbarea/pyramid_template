Inferring the best partition
----------------------------

The simplest and most efficient approach is to find the best
partition of the network by maximizing Eq. :eq:`model-posterior`
according to some version of the model. This is obtained via the
functions :func:`~graph_tool.inference.minimize.minimize_blockmodel_dl` or
:func:`~graph_tool.inference.minimize.minimize_nested_blockmodel_dl`, which
employs an agglomerative multilevel `Markov chain Monte Carlo (MCMC)
<https://en.wikipedia.org/wiki/Markov_chain_Monte_Carlo>`_ algorithm
[peixoto-efficient-2014]_.

We focus first on the non-nested model, and we illustrate its use with a
network of American football teams, which we load from the
:mod:`~graph_tool.collection` module:

.. testsetup:: football

   import os
   try:
      os.chdir("demos/inference")
   except FileNotFoundError:
       pass
   gt.seed_rng(12)

.. testcode:: football

   g = gt.collection.data["football"]
   print(g)

which yields

.. testoutput:: football

   <Graph object, undirected, with 115 vertices and 613 edges, 4 internal vertex properties, 2 internal graph properties, at 0x...>

We then fit the degree-corrected model by calling:

.. testcode:: football

   state = gt.minimize_blockmodel_dl(g)

This returns a :class:`~graph_tool.inference.blockmodel.BlockState` object that
includes the inference results.

.. note::

   The inference algorithm used is stochastic by nature, and may return
   a different answer each time it is run. This may be due to the fact
   that there are alternative partitions with similar probabilities, or
   that the optimum is difficult to find. Note that the inference
   problem here is, in general, `NP-Hard
   <https://en.wikipedia.org/wiki/NP-hardness>`_, hence there is no
   efficient algorithm that is guaranteed to always find the best
   answer.

   Because of this, typically one would call the algorithm many times,
   and select the partition with the largest posterior probability of
   Eq. :eq:`model-posterior`, or equivalently, the minimum description
   length of Eq. :eq:`model-dl`. The description length of a fit can be
   obtained with the :meth:`~graph_tool.inference.blockmodel.BlockState.entropy`
   method. See also Sec. :ref:`sec_model_selection` below.


We may perform a drawing of the partition obtained via the
:mod:`~graph_tool.inference.blockmodel.BlockState.draw` method, that functions as a
convenience wrapper to the :func:`~graph_tool.draw.graph_draw` function

.. testcode:: football

   state.draw(pos=g.vp.pos, output="football-sbm-fit.svg")

which yields the following image.

.. figure:: football-sbm-fit.*
   :align: center
   :width: 400px

   Stochastic block model inference of a network of American college
   football teams. The colors correspond to inferred group membership of
   the nodes.

We can obtain the group memberships as a
:class:`~graph_tool.PropertyMap` on the vertices via the
:mod:`~graph_tool.inference.blockmodel.BlockState.get_blocks` method:

.. testcode:: football

   b = state.get_blocks()
   r = b[10]   # group membership of vertex 10
   print(r)

which yields:

.. testoutput:: football

   3

We may also access the matrix of edge counts between groups via
:mod:`~graph_tool.inference.blockmodel.BlockState.get_matrix`

.. testcode:: football

   e = state.get_matrix()

   matshow(e.todense())
   savefig("football-edge-counts.svg")

.. figure:: football-edge-counts.*
   :align: center

   Matrix of edge counts between groups.

We may obtain the same matrix of edge counts as a graph, which has
internal edge and vertex property maps with the edge and vertex counts,
respectively:

.. testcode:: football

   bg = state.get_bg()
   ers = state.mrs    # edge counts
   nr = state.wr      # node counts

.. _sec_model_selection:

Hierarchical partitions
+++++++++++++++++++++++

The inference of the nested family of SBMs is done in a similar manner,
but we must use instead the
:func:`~graph_tool.inference.minimize.minimize_nested_blockmodel_dl` function. We
illustrate its use with the neural network of the `C. elegans
<https://en.wikipedia.org/wiki/Caenorhabditis_elegans>`_ worm:

.. testsetup:: celegans

   gt.seed_rng(52)

.. testcode:: celegans

   g = gt.collection.data["celegansneural"]
   print(g)

which has 297 vertices and 2359 edges.

.. testoutput:: celegans

   <Graph object, directed, with 297 vertices and 2359 edges, 2 internal vertex properties, 1 internal edge property, 2 internal graph properties, at 0x...>

A hierarchical fit of the degree-corrected model is performed as follows.

.. testcode:: celegans

   state = gt.minimize_nested_blockmodel_dl(g)

The object returned is an instance of a
:class:`~graph_tool.inference.nested_blockmodel.NestedBlockState` class, which
encapsulates the results. We can again draw the resulting hierarchical
clustering using the
:meth:`~graph_tool.inference.nested_blockmodel.NestedBlockState.draw` method:

.. testcode:: celegans

   state.draw(output="celegans-hsbm-fit.pdf")

.. testcleanup:: celegans

   conv_png("celegans-hsbm-fit.pdf")
                 

.. figure:: celegans-hsbm-fit.png
   :align: center
   :width: 80%

   Most likely hierarchical partition of the neural network of
   the *C. elegans* worm according to the nested degree-corrected SBM.

.. note::

   If the ``output`` parameter to
   :meth:`~graph_tool.inference.nested_blockmodel.NestedBlockState.draw` is omitted, an
   interactive visualization is performed, where the user can re-order
   the hierarchy nodes using the mouse and pressing the ``r`` key.

A summary of the inferred hierarchy can be obtained with the
:meth:`~graph_tool.inference.nested_blockmodel.NestedBlockState.print_summary` method,
which shows the number of nodes and groups in all levels:

.. testcode:: celegans

   state.print_summary()

.. testoutput:: celegans

   l: 0, N: 297, B: 19
   l: 1, N: 19, B: 6
   l: 2, N: 6, B: 2
   l: 3, N: 2, B: 1

The hierarchical levels themselves are represented by individual
:meth:`~graph_tool.inference.blockmodel.BlockState` instances obtained via the
:meth:`~graph_tool.inference.nested_blockmodel.NestedBlockState.get_levels()` method:

.. testcode:: celegans

   levels = state.get_levels()
   for s in levels:
       print(s)

.. testoutput:: celegans

   <BlockState object with 19 blocks (19 nonempty), degree-corrected, for graph <Graph object, directed, with 297 vertices and 2359 edges, 2 internal vertex properties, 1 internal edge property, 2 internal graph properties, at 0x...>, at 0x...>
   <BlockState object with 6 blocks (6 nonempty), for graph <Graph object, directed, with 19 vertices and 176 edges, 2 internal vertex properties, 1 internal edge property, at 0x...>, at 0x...>
   <BlockState object with 2 blocks (2 nonempty), for graph <Graph object, directed, with 6 vertices and 30 edges, 2 internal vertex properties, 1 internal edge property, at 0x...>, at 0x...>
   <BlockState object with 1 blocks (1 nonempty), for graph <Graph object, directed, with 2 vertices and 4 edges, 2 internal vertex properties, 1 internal edge property, at 0x...>, at 0x...>

This means that we can inspect the hierarchical partition just as before:

.. testcode:: celegans

   r = levels[0].get_blocks()[46]    # group membership of node 46 in level 0
   print(r)
   r = levels[1].get_blocks()[r]     # group membership of node 46 in level 1
   print(r)
   r = levels[2].get_blocks()[r]     # group membership of node 46 in level 2
   print(r)

.. testoutput:: celegans

   5
   2
   0

Trade-off between memory usage and computation time
+++++++++++++++++++++++++++++++++++++++++++++++++++

The agglomerative algorithm behind
:func:`~graph_tool.inference.minimize.minimize_blockmodel_dl` and
:func:`~graph_tool.inference.minimize.minimize_nested_blockmodel_dl` has
a log-linear complexity on the size of the network, but it makes several
copies of the internal blockmodel state, which can become a problem for
very large networks (i.e. tens of millions of edges or more). An
alternative is to use a greedy algorithm based on a merge-split MCMC
with zero temperature [peixoto-merge-split-2020]_, which requires a
single global state, and thus can reduce memory usage. This is achieved
by following the instructions in Sec. :ref:`sampling`, while setting the
inverse temperature parameter ``beta`` to infinity. For example, an
equivalent to the above minimization for the `C. elegans` network is the
following:

.. testcode:: celegans-mcmc

   g = gt.collection.data["celegansneural"]

   state = gt.NestedBlockState(g)

   for i in range(1000): # this should be sufficiently large
       state.multiflip_mcmc_sweep(beta=np.inf, niter=10)

Whenever possible, this procedure should be repeated several times, and
the result with the smallest description length (obtained via the
:meth:`~graph_tool.inference.blockmodel.BlockState.entropy` method)
should be chosen. Better results still can be obtained, at the expense
of a longer computation time, by using the
:meth:`~graph_tool.inference.mcmc.mcmc_anneal` function, which
implements `simulated annealing
<https://en.wikipedia.org/wiki/Simulated_annealing>`_:

.. testcode:: celegans-mcmc-anneal

   g = gt.collection.data["celegansneural"]

   state = gt.NestedBlockState(g)

   gt.mcmc_anneal(state, beta_range=(1, 10), niter=1000, mcmc_equilibrate_args=dict(force_niter=10))

Any of the above methods should give similar results to the previous
algorithms, while requiring less memory. In terms of quality of the
results, it will vary depending on the data, thus experimentation is
recommended.

.. note::

   Note that both approaches above can be combined, where the
   agglomerative algorithm of
   :func:`~graph_tool.inference.minimize.minimize_blockmodel_dl` or
   :func:`~graph_tool.inference.minimize.minimize_nested_blockmodel_dl`
   is used to find an initial solution, which is then improved via a
   greedy merge-split MCMC, e.g.

   .. testcode:: celegans-mcmc-combine

      g = gt.collection.data["celegansneural"]

      state = gt.minimize_nested_blockmodel_dl(g)

      S1 = state.entropy()
         
      # we will pad the hierarchy with another four empty levels, to
      # give it room to potentially increase
         
      state = state.copy(bs=state.get_bs() + [np.zeros(1)] * 4,
                         sampling = True)

      for i in range(100):
         ret = state.multiflip_mcmc_sweep(niter=10, beta=np.inf)

      S2 = state.entropy()

      print("Improvement:", S2 - S1)

   One run of the above code yields a modest improvement, but depending
   on the dataset the difference can be larger:

   .. testoutput:: celegans-mcmc-combine

      Improvement: -82.616161...