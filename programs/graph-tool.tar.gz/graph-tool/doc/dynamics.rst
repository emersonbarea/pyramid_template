.. automodule:: graph_tool.dynamics
   :members:
   :undoc-members:
   :show-inheritance:
