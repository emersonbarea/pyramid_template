Welcome to graph-tool's documentation!
======================================

Contents:

.. toctree::
   :maxdepth: 3
   :glob:

   quickstart
   gt_format
   demos/index
   modules
   faq

Indexes and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
