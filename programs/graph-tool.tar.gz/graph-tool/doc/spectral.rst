.. automodule:: graph_tool.spectral
   :members:
   :undoc-members:
